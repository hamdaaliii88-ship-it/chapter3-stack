src/stack  -> shared classes, ONE copy: ArrayStack, LinkedStack, Node, EmptyCollectionException
src/partA/ex01..ex03   Part A: java.util.Stack, Box<T>
src/partB/ex04..ex06   Part B: bank, student, reverse string (Reverser)
src/partC/ex07..ex09   Part C: ArrayStack, trace, custom exception
src/partD/ex10..ex15   Part D: linked list, LinkedStack, bank/student
Class names are the same as in the lesson (Main, UndoDepositDemo, ArrayStackTraceDemo ...).
Each example lives in its own folder, so Main can repeat without clashing.
Run all: ./run.sh      Run one: ./run.sh partD.ex13
Ex08 ends with EmptyStackException on purpose (underflow demo).
ArrayStackDemo (ex07) and LinkedStackDemo (ex12) were added; the PDF has no demo for them.
