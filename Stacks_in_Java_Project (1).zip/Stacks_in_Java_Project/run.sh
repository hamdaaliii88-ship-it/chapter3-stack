#!/bin/sh
# Usage:  ./run.sh                      -> compile everything and run ALL examples
#         ./run.sh partD.ex13           -> run just one example (by its package)
cd "$(dirname "$0")"
mkdir -p out && javac -Xlint:none -d out $(find src -name '*.java') || exit 1
run() { # package
  m=$(grep -l "public static void main" src/$(echo $1 | tr . /)/*.java | head -1 | xargs basename | sed 's/\.java//')
  echo "=== $1.$m"
  if [ "$1" = partB.ex06 ]; then echo JAVA | java -cp out $1.$m; else java -cp out $1.$m 2>&1; fi
}
if [ -n "$1" ]; then run "$1"; exit; fi
for d in $(find src/part* -mindepth 1 -maxdepth 1 -type d | sort); do run "$(echo $d | sed 's#src/##; s#/#.#')"; done
