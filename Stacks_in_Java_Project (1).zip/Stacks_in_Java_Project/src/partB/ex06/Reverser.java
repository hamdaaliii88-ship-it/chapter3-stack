package partB.ex06;

import java.util.Stack;

public class Reverser {
    public String reverse(String input) {
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < input.length(); i++)
            stack.push(input.charAt(i));      // J, A, V, A

        String reversed = "";
        while (!stack.isEmpty())
            reversed += stack.pop();          // A, V, A, J
        return reversed;
    }
}
